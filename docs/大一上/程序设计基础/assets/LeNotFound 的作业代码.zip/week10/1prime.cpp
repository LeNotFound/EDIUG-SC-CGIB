#include<bits/extc++.h>

using namespace std;
using namespace __gnu_pbds;
using namespace __gnu_cxx;

inline long long read()
{
    long long x=0,f=1;
    char ch=getchar();
    while(!isdigit(ch))
    {
        if(ch=='-')
        {
            f=-1;
        }
        ch=getchar();
    }
    while(isdigit(ch))
    {
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}

typedef long long ll;
typedef unsigned long long ull;
typedef long double ld;

const ll maxn=1010;

vector<bool> isprime(maxn,true);

void init()
{
    isprime[0]=isprime[1]=false;

    for(ll i=2;i<maxn;i++)
    {
        if(isprime[i])
        {
            for(ll j=i+i;j<maxn;j+=i)
            {
                isprime[j]=false;
            }
        }
    }
}

int main()
{
    init();

    ll n=read();

    if(isprime[n])
    {
        puts("yes");
    }
    else 
    {
        puts("false");
        // 我超 怎么不是no啊
    }
    
    // Debug
    // int Debuger=0;
    // cin>>Debuger;
    return 0;
}