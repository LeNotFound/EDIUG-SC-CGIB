#include<stdio.h>
#include<stdbool.h>

int a[1010][1010];
bool vis[1010][1010];

int main()
{
    int n=0;
    scanf("%d",&n);

    int i,j;

    for(i=0;i<=n+1;i++)
    {
        vis[0][i]=true;
        vis[n+1][i]=true;
        vis[i][0]=true;
        vis[i][n+1]=true;
    }

    int now=1;

    int x=1,y=1;

    a[1][1]=1;

    while((!vis[x+1][y])||(!vis[x-1][y])||(!vis[x][y+1])||(!vis[x][y-1]))
    {
        a[x][y]=now++;
        vis[x][y]=true;
        while(!vis[x][y+1])
        {
            if(vis[x][y+1])
            {
                y--;
                break;
            }
            y++;
            a[x][y]=now++;
            vis[x][y]=true;
        }
        while(!vis[x+1][y])
        {
            if(vis[x+1][y])
            {
                x--;
                break;
            }
            x++;
            a[x][y]=now++;
            vis[x][y]=true;
        }
        while(!vis[x-1][y])
        {
            if(vis[x-1][y])
            {
                x++;
                break;
            }
            x--;
            a[x][y]=now++;
            vis[x][y]=true;
        }
        while(!vis[x][y-1])
        {
            if(vis[x][y-1])
            {
                y++;
                break;
            }
            y--;
            a[x][y]=now++;
            vis[x][y]=true;
        }
        now--;
    }

    for(i=1;i<=n;i++)
    {
        for(j=1;j<=n;j++)
        {
            printf("%5d",a[i][j]);
        }
        putchar('\n');
    }

    return 0;
}