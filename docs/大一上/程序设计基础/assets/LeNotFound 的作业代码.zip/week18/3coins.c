#include<stdio.h>

int cnt;

void print(int a,int b,int c)
{
    printf("fen5: %d fen2: %d fen1: %d\n",a,b,c);
}

int main()
{
    printf("Input money: ");
    int n=0;
    scanf("%d",&n);

    int i,j,k;

    for(i=1;i<=n/5;i++)
    {
        for(j=1;j<=n/2;j++)
        {
            for(k=1;k<=n;k++)
            {
                if(i*5+j*2+k==n)
                {
                    print(i,j,k);
                    cnt++;
                }
            }
        }
    }

    printf("count=%d",cnt);
}