#include<stdio.h>
#include<string.h>

char str[1010];

int main()
{
    int n=0;
    scanf("%d",&n);

    getchar();

    fgets(str,1010,stdin);

    int len=strlen(str);

    int i;

    for(i=0;i<len;i++)
    {
        str[i]+=n;
    }

    printf("%s",str);

    return 0;
}