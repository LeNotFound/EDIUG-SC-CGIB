#include<stdio.h>

int a[1010][1010];

int main()
{
    int n=0;
    scanf("%d",&n);

    int len=n*2-1;

    int i,j;

    int k;

    for(k=1;k<=len;k++)
    {
        for(i=k;i<=len-k+1;i++)
        {
            for(j=k;j<=len-k+1;j++)
            {
                a[i][j]++;
            }
        }
    }

    for(i=1;i<=len;i++)
    {
        for(j=1;j<=len;j++)
        {
            printf("%d",a[i][j]);
        }
        putchar('\n');
    }

    return 0;
}