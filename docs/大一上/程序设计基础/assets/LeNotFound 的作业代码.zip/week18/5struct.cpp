#include<bits/extc++.h>

using namespace std;
using namespace __gnu_pbds;
using namespace __gnu_cxx;

inline long long read()
{
    long long x=0,f=1;
    char ch=getchar();
    while(!isdigit(ch))
    {
        if(ch=='-')
        {
            f=-1;
        }
        ch=getchar();
    }
    while(isdigit(ch))
    {
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}

typedef long long ll;
typedef unsigned long long ull;
typedef long double ld;

struct person
{
    string name;
    ll id;
    ld salary;
    friend bool operator<(person x, person y)
    {
        return x.salary<y.salary;
    }
};

vector<person> a;

int main()
{
    a.resize(3);

    puts("the first person: ");
    puts("name:");
    cin>>a[0].name;
    puts("ID:");
    cin>>a[0].id;
    puts("salary:");
    cin>>a[0].salary;

    puts("the second person: ");
    puts("name:");
    cin>>a[1].name;
    puts("ID:");
    cin>>a[1].id;
    puts("salary:");
    cin>>a[1].salary;

    puts("the third person: ");
    puts("name:");
    cin>>a[2].name;
    puts("ID:");
    cin>>a[2].id;
    puts("salary:");
    cin>>a[2].salary;

    sort(a.begin(),a.end());

    ld tol=0;

    for(ll i=0;i<3;i++)
    {
        tol+=a[i].salary;
    }

    cout<<"the highest salary:"<<fixed<<setprecision(2)<<a[2].salary<<'.';
    putchar('\n');
    cout<<"the average salary:"<<fixed<<setprecision(2)<<tol/3.0L<<'.';
    
    // Debug
    // int Debuger=0;
    // cin>>Debuger;
    return 0;
}