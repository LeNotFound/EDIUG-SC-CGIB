#include<stdio.h>

int a[100010];

int n,m;

int main()
{
    scanf("%d",&n);

    int i;

    for(i=1;i<=n;i++)
    {
        int x=0;
        scanf("%d",&x);
        a[x]++;
    }

    scanf("%d",&m);

    for(i=1;i<=m;i++)
    {
        int x=0;
        scanf("%d",&x);
        a[x]++;
    }

    for(i=0;i<=100000;i++)
    {
        if(a[i]==1)
        {
            printf("%d ",i);
        }
    }    
    
    return 0;
}