#include<bits/extc++.h>

using namespace std;
using namespace __gnu_pbds;
using namespace __gnu_cxx;

inline long long read()
{
    long long x=0,f=1;
    char ch=getchar();
    while(!isdigit(ch))
    {
        if(ch=='-')
        {
            f=-1;
        }
        ch=getchar();
    }
    while(isdigit(ch))
    {
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}

typedef long long ll;
typedef unsigned long long ull;
typedef long double ld;

// 1 3 5 3 2 3 4 1 3 2 6 7
/* 
1 3 5 3
2 3 4 1
3 2 6 7
 */

vector<ll> row;
vector<ll> col;

vector<vector<ll> > a;

int main()
{
    a.resize(4,vector<ll>(5,0));
    row.resize(4,0);
    col.resize(5,LONG_LONG_MAX);

    for(ll i=1;i<=3;i++)
    {
        ll tmp=0;
        for(ll j=1;j<=4;j++)
        {
            a[i][j]=read();
            tmp=max(tmp,a[i][j]);
        }
        row[i]=tmp;
    }

    for(ll i=1;i<=4;i++)
    {
        ll tmp=LONG_LONG_MAX;
        for(ll j=1;j<=3;j++)
        {
            tmp=min(tmp,a[j][i]);
        }
        col[i]=tmp;
    }

    for(ll i=1;i<=3;i++)
    {
        for(ll j=1;j<=4;j++)
        {
            if(a[i][j]==row[i]&&a[i][j]==col[j])
            {
                cout<<"there is a an-dian a["<<i-1<<"]["<<j-1<<"]="<<a[i][j]<<"\n";
                return 0;
            }
        }
    }

    puts("there is no an-dian");
    
    // Debug
    // int Debuger=0;
    // cin>>Debuger;
    return 0;
}