#include<bits/extc++.h>

using namespace std;
using namespace __gnu_pbds;
using namespace __gnu_cxx;

inline long long read()
{
    long long x=0,f=1;
    char ch=getchar();
    while(!isdigit(ch))
    {
        if(ch=='-')
        {
            f=-1;
        }
        ch=getchar();
    }
    while(isdigit(ch))
    {
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}

typedef long long ll;
typedef unsigned long long ull;
typedef long double ld;

ld dist(ld xa,ld ya,ld xb,ld yb)
{
    return sqrtl((xa-xb)*(xa-xb)+(ya-yb)*(ya-yb));
}

int main()
{
    ld xa=0,ya=0,xb=0,yb=0;
    cout<<"Input(x1,y1): ";
    cin>>xa>>ya;
    cout<<"Input(x2,y2): ";
    cin>>xb>>yb;
    cout<<"distance="<<fixed<<setprecision(2)<<dist(xa,ya,xb,yb);
    
    // Debug
    // int Debuger=0;
    // cin>>Debuger;
    return 0;
}