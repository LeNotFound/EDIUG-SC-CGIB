#include<bits/extc++.h>

using namespace std;
using namespace __gnu_pbds;
using namespace __gnu_cxx;

inline long long read()
{
    long long x=0,f=1;
    char ch=getchar();
    while(!isdigit(ch))
    {
        if(ch=='-')
        {
            f=-1;
        }
        ch=getchar();
    }
    while(isdigit(ch))
    {
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}

typedef long long ll;
typedef unsigned long long ull;
typedef long double ld;

const ll maxn = 1e5 + 10;

struct Bigint
{
    ll v[maxn] = {0};
    ll len = 0;

    void read()
    {
        string s;
        cin >> s;
        if (s == "0")
        {
            return;
        }
        len = s.length();
        for (ll i = 1; i <= len; i++)
        {
            v[i] = s[len - i] - '0';
        }
    }

    void edit_value(string s)
    {
        if (s == "0")
        {
            return;
        }
        len = s.length();
        for (ll i = 1; i <= len; i++)
        {
            v[i] = s[len - i] - '0';
        }
    }

    void print()
    {
        if (len == 0)
        {
            printf("0");
        }
        for (ll i = len; i >= 1; i--)
        {
            printf("%lld", v[i]);
        }
        cout << endl;
    }

    Bigint cpy() const
    {
        Bigint b;
        b.len = len;
        for (ll i = 1; i <= len; i++)
        {
            b.v[i] = v[i];
        }
        return b;
    }

    void get(const ll &k)
    {
        len = 0;
        ll t = k;
        while (t > 0)
        {
            len++;
            v[len] = t % 10;
            t /= 10;
        }
    }

    Bigint operator+(const Bigint &b) const
    {
        Bigint c;
        c.len = max(len, b.len);
        for (ll i = 1; i <= c.len; i++)
        {
            c.v[i] += v[i] + b.v[i];
            c.v[i + 1] += c.v[i] / 10;
            c.v[i] %= 10;
        }
        if (c.v[c.len + 1] > 0)
        {
            c.len++;
        }
        return c;
    }

    Bigint operator-(const Bigint &b) const
    {
        Bigint c;
        c.len = len;
        for (ll i = 1; i <= c.len; i++)
        {
            c.v[i] += v[i] - b.v[i] + 10;
            c.v[i + 1] += c.v[i] / 10 - 1;
            c.v[i] %= 10;
        }
        while (c.len > 0 && c.v[c.len] == 0)
        {
            c.len--;
        }
        return c;
    }

    Bigint operator*(const Bigint &b) const
    {
        Bigint c;
        if (len == 0 || b.len == 0)
        {
            return c;
        }
        for (ll i = 1; i <= len; i++)
        {
            for (ll j = 1; j <= b.len; j++)
            {
                c.v[i + j - 1] += v[i] * b.v[j];
                c.v[i + j] += c.v[i + j - 1] / 10;
                c.v[i + j - 1] %= 10;
            }
        }
        c.len = len + b.len - 1;
        while (c.v[c.len + 1] > 0)
        {
            c.len++;
            c.v[c.len + 1] += c.v[c.len] / 10;
            c.v[c.len] %= 10;
        }
        return c;
    }

    Bigint operator/(const Bigint &b) const
    {
        Bigint c;
        Bigint rem;
        for (ll i = len; i >= 1; i--)
        {
            rem = rem * 10 + v[i];
            while (rem >= b)
            {
                rem = rem - b;
                c.v[i]++;
            }
            if (c.v[i] > 0 && c.len == 0)
            {
                c.len = i;
            }
        }
        return c;
    }

    Bigint operator%(const Bigint &b) const
    {
        Bigint c = this->cpy();
        return (c - ((c / b) * b));
    }

    Bigint operator+(const ll &k) const
    {
        Bigint c;
        ll t = k;
        c.len = len;
        if (c.len == 0 && k > 0)
        {
            c.len = 1;
        }
        for (ll i = 1; i <= c.len; i++)
        {
            c.v[i] += v[i] + t % 10;
            t /= 10;
            c.v[i + 1] += c.v[i] / 10;
            c.v[i] %= 10;
            if (c.v[c.len + 1] > 0 || (i == c.len && t > 0))
            {
                c.len++;
            }
        }
        return c;
    }

    Bigint operator-(const ll &k) const
    {
        Bigint c;
        c.len = len;
        ll t = k;
        for (ll i = 1; i <= c.len; i++)
        {
            c.v[i] += v[i] + 10 - t % 10;
            t /= 10;
            c.v[i + 1] += c.v[i] / 10 - 1;
            c.v[i] %= 10;
        }
        while (c.len > 0 && c.v[c.len] == 0)
        {
            c.len--;
        }
        return c;
    }

    Bigint operator*(const ll &k) const
    {
        Bigint c;
        if (len == 0 || k == 0)
        {
            return c;
        }
        c.len = len;
        for (ll i = 1; i <= len; i++)
        {
            c.v[i] += v[i] * k;
            c.v[i + 1] += c.v[i] / 10;
            c.v[i] %= 10;
        }
        while (c.v[c.len + 1] > 0)
        {
            c.len++;
            c.v[c.len + 1] += c.v[c.len] / 10;
            c.v[c.len] %= 10;
        }
        return c;
    }

    Bigint operator/(const ll &k) const
    {
        Bigint c;
        ll rem = 0;
        for (ll i = len; i >= 1; i--)
        {
            rem = rem * 10 + v[i];
            c.v[i] = rem / k;
            rem %= k;
            if (c.v[i] > 0 && c.len == 0)
            {
                c.len = i;
            }
        }
        return c;
    }

    Bigint operator%(const ll &k) const
    {
        Bigint c = this->cpy();
        return (c - ((c / k) * k));
    }

    bool operator==(const Bigint &b) const
    {
        if (len != b.len)
        {
            return false;
        }
        for (ll i = 1; i <= len; i++)
        {
            if (v[i] != b.v[i])
            {
                return false;
            }
        }
        return true;
    }

    bool operator!=(const Bigint &b) const
    {
        Bigint c = this->cpy();
        return !(c == b);
    }

    bool operator>(const Bigint &b) const
    {
        if (len != b.len)
        {
            return len > b.len;
        }
        for (ll i = len; i >= 1; i--)
        {
            if (v[i] != b.v[i])
            {
                return (v[i] > b.v[i]);
            }
        }
        return false;
    }

    bool operator>=(const Bigint &b) const
    {
        Bigint c = this->cpy();
        return (c == b || c > b);
    }

    bool operator<(const Bigint &b) const
    {
        Bigint c = this->cpy();
        return !(c >= b);
    }

    bool operator<=(const Bigint &b) const
    {
        Bigint c = this->cpy();
        return !(c > b);
    }
};

Bigint jiec(Bigint x)
{
    Bigint ret;
    ret.get(1);
    Bigint i;
    i.get(1);
    for (; i <= x; i = i + 1)
    {
        ret = ret * i;
    }
    return ret;
}

Bigint quickpow(Bigint base, Bigint p)
{
    Bigint ret;
    ret.get(1);
    Bigint zero;
    zero.get(0);
    Bigint one;
    one.get(1);
    while (p > zero)
    {
        if (p % 2 == one)
        {
            ret = ret * base;
        }
        base = base * base;
        p = p / 2;
    }
    return ret;
}

Bigint e;
ld x;

ld funcos()
{
    Bigint ret;
    ret.get(0);

    bool sign=1;

    Bigint i;
    i.get(0);

    for(;;i=i+2)
    {
        Bigint fenzi;
        fenzi=quickpow(x,i);
    }
}

int main()
{
    cout<<"e: ";
    ld tmp;
    cin>>tmp;
    e.get(1.0L/tmp);
    cout<<"x: ";
    cin>>x;

    
    // Debug
    // int Debuger=0;
    // cin>>Debuger;
    return 0;
}