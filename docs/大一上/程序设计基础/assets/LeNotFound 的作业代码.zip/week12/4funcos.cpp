#include<bits/extc++.h>

using namespace std;
using namespace __gnu_pbds;
using namespace __gnu_cxx;

inline long long read()
{
    long long x=0,f=1;
    char ch=getchar();
    while(!isdigit(ch))
    {
        if(ch=='-')
        {
            f=-1;
        }
        ch=getchar();
    }
    while(isdigit(ch))
    {
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}

typedef long long ll;
typedef unsigned long long ull;
typedef long double ld;

ld funcos(ld e,ld x)
{
    ld ret=1.0L;
    ld now=1.0L;

    for(ll i=2;;i+=2)
    {
        now*=-x*x/(i*(i-1));    // 我们充分发扬人类智慧，避免阶乘爆 LL
        if(fabsl(now)<e)
        {
            break;
        }
        ret+=now;
    }

    return ret;
}

int main()
{
    cout<<"e: ";
    ld e=0.0L;
    cin>>e;
    cout<<"x: ";
    ld x=0.0L;
    cin>>x;
    ld ans=funcos(e,x);
    // 这不对吧 20! 爆 long long 了啊
    cout<<"cos(x)="<<fixed<<setprecision(3)<<ans;
    
    // Debug
    // int Debuger=0;
    // cin>>Debuger;
    return 0;
}