#include<bits/extc++.h>

using namespace std;
using namespace __gnu_pbds;
using namespace __gnu_cxx;

inline long long read()
{
    long long x=0,f=1;
    char ch=getchar();
    while(!isdigit(ch))
    {
        if(ch=='-')
        {
            f=-1;
        }
        ch=getchar();
    }
    while(isdigit(ch))
    {
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}

typedef long long ll;
typedef unsigned long long ull;
typedef long double ld;

int main()
{
    // puts("Input n: ");
    cout<<"Input n: ";

    ll n=read();

    ld ans=0;

    for(ll i=0;i<=n;i++)
    {
        ll fenmu=1;

        for(ll j=1;j<=i;j++)
        {
            fenmu*=j;
        }

        ans+=(ld)1/(ld)fenmu;
    }

    cout<<"e="<<fixed<<setprecision(4)<<ans;
    
    // Debug
    // int Debuger=0;
    // cin>>Debuger;
    return 0;
}