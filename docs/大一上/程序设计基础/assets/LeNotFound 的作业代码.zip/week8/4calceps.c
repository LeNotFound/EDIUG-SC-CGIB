#include<stdio.h>
#include<math.h>
#include<stdlib.h>
#include<stdbool.h>

typedef double ld;

ld ldabs(ld x)
{
    if(x<0.0L)
    {
        x*=-1.0L;
    }
    return x;
}

int main()
{
    printf("Input eps: ");

    ld a=0.0L;

    scanf("%lf",&a);

    ld fenmu=4;

    bool pos=0;

    ld s=1.0L;

    while(ldabs((ld)1/(ld)fenmu)>=a)
    {
        if(pos)
        {
            s+=(ld)1/(ld)fenmu;
        }
        else 
        {
            s-=(ld)1/(ld)fenmu;
        }
        fenmu+=3;
        pos=!pos;
    }

    printf("s=%.6lf",s);

    return 0;
}