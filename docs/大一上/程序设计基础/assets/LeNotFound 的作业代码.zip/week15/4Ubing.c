#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<stdbool.h>

int a[1010];
void init()
{
    memset(a,0,sizeof(a));
}

int cmp(const void *a,const void *b)
{
    return *(int *)b-*(int *)a;
}

int main()
{
    init();

    int n=0,m=0;

    scanf("%d",&n);

    int i;

    for(i=0;i<n;i++)
    {
        scanf("%d",&a[i]);
    }

    scanf("%d",&m);

    for(i=n;i<n+m;i++)
    {
        scanf("%d",&a[i]);
    }

    qsort(a,n+m,sizeof(int),cmp);

    for(i=0;i<n+m;i++)
    {
        if(a[i]==a[i-1]&&i!=0)
        {
            continue;
        }
        printf("%d ",a[i]);
    }

    return 0;
}