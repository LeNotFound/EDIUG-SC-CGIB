#include<bits/extc++.h>

using namespace std;
using namespace __gnu_pbds;
using namespace __gnu_cxx;

inline long long read()
{
    long long x=0,f=1;
    char ch=getchar();
    while(!isdigit(ch))
    {
        if(ch=='-')
        {
            f=-1;
        }
        ch=getchar();
    }
    while(isdigit(ch))
    {
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}

typedef long long ll;
typedef unsigned long long ull;
typedef long double ld;

int main()
{
    puts("The original product life data are:");
    vector<ld> a;

    ld minn=LONG_LONG_MAX;
    ld maxn=LONG_LONG_MIN;

    ld sum=0.0L;
    ld ave=0.0L;

    ld stdcz=0.0L;

    a.resize(12);

    for(ll i=1;i<=11;i++)
    {
        cin>>a[i];
        minn=min(minn,a[i]);
        maxn=max(maxn,a[i]);
        sum+=a[i];
    }

    sort(a.begin()+1,a.end());

    puts("The sorted product life data are:");

    for(ll i=1;i<=11;i++)
    {
        cout<<fixed<<setprecision(2)<<showpoint<<a[i]<<" \n"[i==11];
    }

    ave=sum/11.0L;

    for(ll i=1;i<=11;i++)
    {
        stdcz+=fabsl(a[i]-ave)*fabsl(a[i]-ave);
    }

    stdcz/=11.0L;

    stdcz=sqrtl(stdcz);

    cout<<fixed<<setprecision(2)<<showpoint;

    cout<<"Max:"<<maxn<<",Min:"<<minn<<",Med:"<<a[6]<<",Ave:"<<ave<<",Std:"<<stdcz;
    
    // Debug
    // int Debuger=0;
    // cin>>Debuger;
    return 0;
}