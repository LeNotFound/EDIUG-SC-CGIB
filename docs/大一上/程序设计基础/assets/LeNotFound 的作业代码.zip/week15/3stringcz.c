#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<stdbool.h>
#include<ctype.h>

char a[1010],b[1010];
char c[1010];
char d[1010];

void init()
{
    memset(a,0,sizeof(a));
    memset(b,0,sizeof(b));
    memset(c,0,sizeof(c));
    memset(d,0,sizeof(d));
}

int char_cmp(const void *x,const void *y)
{
    return *(char *)x-*(char *)y;
}

int main()
{
    init();

    gets(a);
    gets(b);

    int i,j;
    int p=0;
    int q=0;

    for(i=0;i<strlen(a);i++)
    {
        for(j=0;j<strlen(b);j++)
        {
            char tmp1=tolower(a[i]);
            char tmp2=tolower(b[j]);
            if(tmp1==tmp2)
            {
                c[p++]=a[i];
                break;
            }
        }
    }

    for(i=0;i<strlen(a);i++)
    {
        bool flag=true;
        for(j=0;j<strlen(c);j++)
        {
            if(a[i]==c[j])
            {
                flag=false;
                break;
            }
        }
        if(flag)
        {
            d[q++]=a[i];
        }
    }

    // for(i=0;i<strlen(b);i++)
    // {
    //     bool flag=true;
    //     for(j=0;j<strlen(c);j++)
    //     {
    //         if(b[i]==c[j])
    //         {
    //             flag=false;
    //             break;
    //         }
    //     }
    //     if(flag)
    //     {
    //         d[q++]=b[i];
    //     }
    // }

    if(q==0&&d[0]=='\0')
    {
        puts("NULL");
    }
    else 
    {
        qsort(d,strlen(d),sizeof(char),char_cmp);
        for(i=0;i<strlen(d);i++)
        {
            // if(d[i]>d[i+1])
            // {
            //     break;
            // }
            putchar(d[i]);
        }
    }

    return 0;
}