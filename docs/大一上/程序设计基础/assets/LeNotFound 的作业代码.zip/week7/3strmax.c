#include<stdio.h>
#include<string.h>

char str[5][5010];

int len[5];

int main()
{
    printf("Input 5 strings:");

    int i=0;
    // 可恶的 C99 标准……

    for(;i<5;i++)
    {
        scanf("%s",str[i]);
        // 依次读入，字符串存入到 str 数组里
        len[i]=strlen(str[i]);
        // 同时存各个字符串的长度放到 len 数组里
    }

    int mxlen=-1;   // 用于存储最大的长度

    int p=-1;       // 用来存储最大的长度所对应的下标

    i=0;            // C99………………╰（‵□′）╯

    for(;i<5;i++)   // 循环遍历 5 个字符串
    {
        if(len[i]>mxlen)    // 如果遇到比最大长度大的，就
        {
            mxlen=len[i];   // 更新最大长度
            p=i;            // 同时更新最大长度对应的下标
        }
    }

    // 直接输出对应下标的字符串

    printf("The longest is:%s",str[p]);

    return 0;
}