#include<stdio.h>
#include<string.h>

int letter;
int blank;
int digit;
int other;

char str[5010];

int main()
{
    gets(str);

    int i=0;

    for(;i<strlen(str);i++)
    {
        if((str[i]>='A'&&str[i]<='Z')||(str[i]>='a'&&str[i]<='z'))
        {
            letter++;
        }
        else if(str[i]==' ')
        {
            blank++;
        }
        else if(str[i]>='0'&&str[i]<='9')
        {
            digit++;
        }
        else 
        {
            other++;
        }
    }

    printf("letter=%d,blank=%d,digit=%d,other=%d",letter,blank,digit,other);

    return 0;
}