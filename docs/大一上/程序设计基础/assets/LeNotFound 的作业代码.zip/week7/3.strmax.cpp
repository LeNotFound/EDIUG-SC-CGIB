#include<bits/extc++.h>

using namespace std;
using namespace __gnu_pbds;
using namespace __gnu_cxx;

inline long long read()
{
    long long x=0,f=1;
    char ch=getchar();
    while(!isdigit(ch))
    {
        if(ch=='-')
        {
            f=-1;
        }
        ch=getchar();
    }
    while(isdigit(ch))
    {
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}

typedef long long ll;
typedef unsigned long long ull;
typedef long double ld;

__gnu_pbds::priority_queue<pair<ll,ll>> q;

vector<string> str;

int main()
{
    cout<<"Input 5 srings:";

    for(ll i=0;i<5;i++)
    {
        string tmp;
        cin>>tmp;
        str.push_back(tmp);
        q.push(make_pair(tmp.length(),i));
    }

    cout<<"The longest is:"<<str[q.top().second];
    
    // Debug
    // int Debuger=0;
    // cin>>Debuger;
    return 0;
}