#include <stdio.h>

int main() {
    int a = 123;
    int b = 233;
    float c = 232.346;
    float d = 233.0;
    char e[] = "left aligned string";

    printf("%d\n", a);
    printf("%4X\n", b);
    printf("%10.3f\n", c);
    printf("%12.2e\n", d);
    printf("%-30s\n", e);

    return 0;
}
