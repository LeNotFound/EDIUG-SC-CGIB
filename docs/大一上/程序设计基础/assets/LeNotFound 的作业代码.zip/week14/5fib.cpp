#include<bits/extc++.h>

using namespace std;
using namespace __gnu_pbds;
using namespace __gnu_cxx;

inline long long read()
{
    long long x=0,f=1;
    char ch=getchar();
    while(!isdigit(ch))
    {
        if(ch=='-')
        {
            f=-1;
        }
        ch=getchar();
    }
    while(isdigit(ch))
    {
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}

typedef long long ll;
typedef unsigned long long ull;
typedef long double ld;

ll fib[110];
set<ll> fibs;

void init()
{
    fib[1]=1;
    fib[2]=1;
    for(ll i=3;i<110;i++)
    {
        fib[i]=fib[i-1]+fib[i-2];
        fibs.insert(fib[i]);
    }
}

int main()
{
    init();

    cout<<"Input m: ";
    ll n=read();
    cout<<"Input n: ";
    ll m=read();

    set<ll>::iterator it=fibs.lower_bound(n);

    for(;it!=fibs.upper_bound(m);it++)
    {
        cout<<*it<<" ";
    }
    
    // Debug
    // int Debuger=0;
    // cin>>Debuger;
    return 0;
}