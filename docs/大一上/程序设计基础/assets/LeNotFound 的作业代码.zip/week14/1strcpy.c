#include<stdio.h>
#include<string.h>

char *substr(char *s,int p)
{
    if(p==0)
    {
        return s;
    }
    char *ans=s+p-1;
    return ans;
}

char *strmcpy(char *s,char *t,int m)
{
    s=substr(t, m);
    return s;
}

char ans[100];

void init()
{
    memset(ans, 0, sizeof(ans));
}

int main()
{
    init();

    printf("Input a string:");
    char str[100];
    gets(str);

    printf("Input an integer:");
    int n=0;
    scanf("%d", &n);

    printf("Output is:");
    printf("%s", strmcpy(ans, str, n));

    return 0;
}