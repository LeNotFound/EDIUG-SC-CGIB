#include<stdio.h>
#include<stdlib.h>
#include<string.h>

char *delchar(char *s,char c)
{
    char *ret=(char *)malloc(sizeof(char)*100);
    memset(ret,0,sizeof(ret));
    int lens=strlen(s);

    int i=0;
    int p=0;
    for(i;i<lens;i++)
    {
        if(s[i]==c)
        {
            continue;
        }
        ret[p++]=s[i];
    }

    return ret;
}

int main()
{
    printf("Input a string:");

    char str[100];

    gets(str);

    printf("Input a char:");

    char c;

    scanf("%c",&c);

    printf("After deleted,the string is:%s",delchar(str,c));

    return 0;
}