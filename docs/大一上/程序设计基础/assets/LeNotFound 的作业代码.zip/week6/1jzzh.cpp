#include<bits/extc++.h>

using namespace std;
using namespace __gnu_pbds;
using namespace __gnu_cxx;

inline long long read()
{
    long long x=0,f=1;
    char ch=getchar();
    while(!isdigit(ch))
    {
        if(ch=='-')
        {
            f=-1;
        }
        ch=getchar();
    }
    while(isdigit(ch))
    {
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}

typedef long long ll;
typedef unsigned long long ull;
typedef long double ld;

string lltostr(long long i)
{
    ostringstream os;
    os << i;
    string res;
    istringstream is(os.str());
    is >> res;
    return res;
}

string ten2k(int k, int n)
{
    string ans;
    string tmp;
    while (n)
    {
        if (n % k == 10)
        {
            tmp += 'A';
        }
        else if (n % k == 11)
        {
            tmp += 'B';
        }
        else if (n % k == 12)
        {
            tmp += 'C';
        }
        else if (n % k == 13)
        {
            tmp += 'D';
        }
        else if (n % k == 14)
        {
            tmp += 'E';
        }
        else if (n % k == 15)
        {
            tmp += 'F';
        }
        else if (n % k == 16)
        {
            tmp += 'G';
        }
        else if (n % k == 17)
        {
            tmp += 'H';
        }
        else if (n % k == 18)
        {
            tmp += 'I';
        }
        else if (n % k == 19)
        {
            tmp += 'J';
        }
        else if (n % k == 20)
        {
            tmp += 'K';
        }
        else if (n % k == 21)
        {
            tmp += 'L';
        }
        else if (n % k == 22)
        {
            tmp += 'M';
        }
        else if (n % k == 23)
        {
            tmp += 'N';
        }
        else if (n % k == 24)
        {
            tmp += 'O';
        }
        else if (n % k == 25)
        {
            tmp += 'P';
        }
        else if (n % k == 26)
        {
            tmp += 'Q';
        }
        else if (n % k == 27)
        {
            tmp += 'R';
        }
        else if (n % k == 28)
        {
            tmp += 'S';
        }
        else if (n % k == 29)
        {
            tmp += 'T';
        }
        else if (n % k == 30)
        {
            tmp += 'U';
        }
        else if (n % k == 31)
        {
            tmp += 'V';
        }
        else if (n % k == 32)
        {
            tmp += 'W';
        }
        else if (n % k == 33)
        {
            tmp += 'X';
        }
        else if (n % k == 34)
        {
            tmp += 'Y';
        }
        else if (n % k == 35)
        {
            tmp += 'Z';
        }
        else
        {
            tmp += lltostr(n % k);
        }
        n -= n % k;
        n /= k;
    }
    while (!tmp.empty())
    {
        ans += tmp.back();
        tmp.pop_back();
    }
    return ans;
}

int k2ten(string s, ll k)
{
    ll n = 0;

    for (int i = s.length() - 1; i >= 0; i--)
    {
        if (s[i] == 'A')
        {
            n += 10 * pow(k, s.length() - 1 - i);
        }
        else if (s[i] == 'B')
        {
            n += 11 * pow(k, s.length() - 1 - i);
        }
        else if (s[i] == 'C')
        {
            n += 12 * pow(k, s.length() - 1 - i);
        }
        else if (s[i] == 'D')
        {
            n += 13 * pow(k, s.length() - 1 - i);
        }
        else if (s[i] == 'E')
        {
            n += 14 * pow(k, s.length() - 1 - i);
        }
        else if (s[i] == 'F')
        {
            n += 15 * pow(k, s.length() - 1 - i);
        }
        else if (s[i] == 'G')
        {
            n += 16 * pow(k, s.length() - 1 - i);
        }
        else if (s[i] == 'H')
        {
            n += 17 * pow(k, s.length() - 1 - i);
        }
        else if (s[i] == 'I')
        {
            n += 18 * pow(k, s.length() - 1 - i);
        }
        else if (s[i] == 'J')
        {
            n += 19 * pow(k, s.length() - 1 - i);
        }
        else if (s[i] == 'K')
        {
            n += 20 * pow(k, s.length() - 1 - i);
        }
        else if (s[i] == 'L')
        {
            n += 21 * pow(k, s.length() - 1 - i);
        }
        else if (s[i] == 'M')
        {
            n += 22 * pow(k, s.length() - 1 - i);
        }
        else if (s[i] == 'N')
        {
            n += 23 * pow(k, s.length() - 1 - i);
        }
        else if (s[i] == 'O')
        {
            n += 24 * pow(k, s.length() - 1 - i);
        }
        else if (s[i] == 'P')
        {
            n += 25 * pow(k, s.length() - 1 - i);
        }
        else if (s[i] == 'Q')
        {
            n += 26 * pow(k, s.length() - 1 - i);
        }
        else if (s[i] == 'R')
        {
            n += 27 * pow(k, s.length() - 1 - i);
        }
        else if (s[i] == 'S')
        {
            n += 28 * pow(k, s.length() - 1 - i);
        }
        else if (s[i] == 'T')
        {
            n += 29 * pow(k, s.length() - 1 - i);
        }
        else if (s[i] == 'U')
        {
            n += 30 * pow(k, s.length() - 1 - i);
        }
        else if (s[i] == 'V')
        {
            n += 31 * pow(k, s.length() - 1 - i);
        }
        else if (s[i] == 'W')
        {
            n += 32 * pow(k, s.length() - 1 - i);
        }
        else if (s[i] == 'X')
        {
            n += 33 * pow(k, s.length() - 1 - i);
        }
        else if (s[i] == 'Y')
        {
            n += 34 * pow(k, s.length() - 1 - i);
        }
        else if (s[i] == 'Z')
        {
            n += 35 * pow(k, s.length() - 1 - i);
        }
        else if (s[i] == '0')
        {
            continue;
        }
        else if (s[i] == '1')
        {
            n += 1 * pow(k, s.length() - 1 - i);
        }
        else if (s[i] == '2')
        {
            n += 2 * pow(k, s.length() - 1 - i);
        }
        else if (s[i] == '3')
        {
            n += 3 * pow(k, s.length() - 1 - i);
        }
        else if (s[i] == '4')
        {
            n += 4 * pow(k, s.length() - 1 - i);
        }
        else if (s[i] == '5')
        {
            n += 5 * pow(k, s.length() - 1 - i);
        }
        else if (s[i] == '6')
        {
            n += 6 * pow(k, s.length() - 1 - i);
        }
        else if (s[i] == '7')
        {
            n += 7 * pow(k, s.length() - 1 - i);
        }
        else if (s[i] == '8')
        {
            n += 8 * pow(k, s.length() - 1 - i);
        }
        else if (s[i] == '9')
        {
            n += 9 * pow(k, s.length() - 1 - i);
        }
    }
    return n;
}

string k2m(int k,int m,string n)
{
    int ret=0;
    ret=k2ten(n,k);
    string ans;
    ans=ten2k(m,ret);
    return ans;
}

ll n;

int main()
{
    cout<<"Input a decimal: ";

    n=read();

    cout<<"The octal is "<<ten2k(8,n)<<endl;

    cout<<"The hexadecimal is "<<ten2k(16,n)<<endl;
    
    // Debug
    // int Debuger=0;
    // cin>>Debuger;
    return 0;
}