#include<stdio.h>

#define maxn 5000

char xing[maxn];
char ming[maxn];

int main()
{
    scanf("%s",&ming);
    scanf("%s",&xing);

    printf("%s %s\n",ming,xing);

    printf("%s\n%s\n",ming,xing);

    printf("%s %s\n",ming,xing);

    return 0;
}