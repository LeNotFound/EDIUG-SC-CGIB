#include<stdio.h>

long double a;

int main()
{
    puts("Enter a floating-point value:");

    scanf("%Lf",&a);

    printf("fixed-point notation: %Lf\n",a);

    printf("exponential notation: %e",a);

    return 0;
}