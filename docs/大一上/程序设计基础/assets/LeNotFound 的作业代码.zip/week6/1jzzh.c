#include<stdio.h>
#include<string.h>

typedef long long ll;

// const ll maxn = 5000;
#define maxn 5000

ll n;
char c[maxn];

void init()
{
    memset(c,0,sizeof(c));
}

void printOct(ll x)
{
    ll i=0;
    while(x)
    {
        c[i++]=(char)x%8+'1'-1;
        x/=8;
    }

    printf("The octal is ");

    ll j=0;
    for(j=--i;j>=0;j--)
    {
        printf("%c",c[j]);
    }
}

void printHex(ll x)
{
    ll i=0;
    while(x)
    {
        if(x%16==10)
        {
            c[i++]='A';
        }
        else if(x%16==11)
        {
            c[i++]='B';
        }
        else if(x%16==12)
        {
            c[i++]='C';
        }
        else if(x%16==13)
        {
            c[i++]='D';
        }
        else if(x%16==14)
        {
            c[i++]='E';
        }
        else if(x%16==15)
        {
            c[i++]='F';
        }
        else 
        {
            c[i++]=(char)(x%16)+'1'-1;
        }
        x/=16;
    }
    
    printf("The hexadecimal is ");

    ll j=0;
    for(j=--i;j>=0;j--)
    {
        printf("%c",c[j]);
    }
}

int main()
{
    printf("Input a decimal: ");

    scanf("%lld",&n);

    printOct(n);

    putchar('\n');

    init();

    printHex(n);

    // for 循环只支持 C99 标准的格式是什么鬼啊！这么古老的东西还在用
    // ヽ（≧□≦）ノ

/*  printf 大法好！！！
    printf("The octal is %o\n",n);

    printf("The hexadecimal is %X\n",n);
 */
    return 0;
}