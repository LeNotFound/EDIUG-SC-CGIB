#include<stdio.h>

void two()
{
    puts("two");
}

void one_three()
{
    puts("one");

    two();

    puts("three");
}

int main()
{
    puts("Staring now:");

    one_three();

    puts("Done!");

    return 0;
}