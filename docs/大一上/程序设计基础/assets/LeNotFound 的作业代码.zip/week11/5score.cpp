#include<bits/extc++.h>

using namespace std;
using namespace __gnu_pbds;
using namespace __gnu_cxx;

inline long long read()
{
    long long x=0,f=1;
    char ch=getchar();
    while(!isdigit(ch))
    {
        if(ch=='-')
        {
            f=-1;
        }
        ch=getchar();
    }
    while(isdigit(ch))
    {
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}

typedef long long ll;
typedef unsigned long long ull;
typedef long double ld;

int main()
{
    ll x = read();

    if (x < 60) {
        cout << "D" << endl;
    } else if (x >= 60 && x <= 69) {
        cout << "C" << endl;
    } else if (x >= 70 && x <= 89) {
        cout << "B" << endl;
    } else {
        cout << "A" << endl;
    }
    
    // Debug
    // int Debuger=0;
    // cin>>Debuger;
    return 0;
}