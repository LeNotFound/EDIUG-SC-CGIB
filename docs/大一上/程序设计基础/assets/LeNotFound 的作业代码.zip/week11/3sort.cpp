#include<bits/extc++.h>

using namespace std;
using namespace __gnu_pbds;
using namespace __gnu_cxx;

inline long long read()
{
    long long x=0,f=1;
    char ch=getchar();
    while(!isdigit(ch))
    {
        if(ch=='-')
        {
            f=-1;
        }
        ch=getchar();
    }
    while(isdigit(ch))
    {
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}

typedef long long ll;
typedef unsigned long long ull;
typedef long double ld;

int main()
{
    vector<ll> a(4);

    for(ll i=0;i<4;i++)
    {
        a[i]=read();
    }

    sort(a.begin(),a.end());

    for(ll i=0;i<4;i++)
    {
        cout<<a[i]<<" ";
    }
    
    // Debug
    // int Debuger=0;
    // cin>>Debuger;
    return 0;
}