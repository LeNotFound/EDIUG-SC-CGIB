#include<bits/extc++.h>

using namespace std;
using namespace __gnu_pbds;
using namespace __gnu_cxx;

inline long long read()
{
    long long x=0,f=1;
    char ch=getchar();
    while(!isdigit(ch))
    {
        if(ch=='-')
        {
            f=-1;
        }
        ch=getchar();
    }
    while(isdigit(ch))
    {
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}

typedef long long ll;
typedef unsigned long long ull;
typedef long double ld;

int main()
{
    ll x = read();
    x*=10000;
    ld ans = 0;

    if (x <= 100000) {
        ans = x * 0.1;
    } else if (x <= 200000) {
        ans = 100000 * 0.1 + (x - 100000) * 0.075;
    } else if (x <= 400000) {
        ans = 100000 * 0.1 + 100000 * 0.075 + (x - 200000) * 0.05;
    } else if (x <= 600000) {
        ans = 100000 * 0.1 + 100000 * 0.075 + 200000 * 0.05 + (x - 400000) * 0.03;
    } else if (x <= 1000000) {
        ans = 100000 * 0.1 + 100000 * 0.075 + 200000 * 0.05 + 200000 * 0.03 + (x - 600000) * 0.015;
    } else {
        ans = 100000 * 0.1 + 100000 * 0.075 + 200000 * 0.05 + 200000 * 0.03 + 400000 * 0.015 + (x - 1000000) * 0.01;
    }

    cout<<"Bonus is "<<ans/10000.0L<<" wan yuan";
    
    // Debug
    // int Debuger=0;
    // cin>>Debuger;
    return 0;
}