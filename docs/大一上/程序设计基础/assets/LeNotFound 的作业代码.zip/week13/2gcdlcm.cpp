#include<bits/extc++.h>

using namespace std;
using namespace __gnu_pbds;
using namespace __gnu_cxx;

inline long long read()
{
    long long x=0,f=1;
    char ch=getchar();
    while(!isdigit(ch))
    {
        if(ch=='-')
        {
            f=-1;
        }
        ch=getchar();
    }
    while(isdigit(ch))
    {
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}

typedef long long ll;
typedef unsigned long long ull;
typedef long double ld;

ll lcm(ll a,ll b)
{
    return a/__gcd(a,b)*b;
}

ll gcd(ll a,ll b,ll c)
{
    return __gcd(a,__gcd(b,c));
}

ll lcm(ll a,ll b,ll c)
{
    return lcm(a,lcm(b,c));
}

int main()
{
    ll a=read();
    ll b=read();
    ll c=read();

    cout<<gcd(a,b,c)<<" "<<lcm(a,b,c);
    
    // Debug
    // int Debuger=0;
    // cin>>Debuger;
    return 0;
}