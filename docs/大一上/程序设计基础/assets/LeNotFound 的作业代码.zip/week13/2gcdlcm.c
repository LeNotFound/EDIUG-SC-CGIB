#include<stdio.h>
#include<math.h>

int gcd(int a,int b)
{
    return b==0?a:gcd(b,a%b);
}

int lcm(int a,int b)
{
    return a*b/gcd(a,b);
}

int gcd3(int a,int b,int c)
{
    return gcd(a,gcd(b,c));
}

int lcm3(int a,int b,int c)
{
    return lcm(a,lcm(b,c));
}

int main()
{
    int a=0,b=0,c=0;

    scanf("%d %d %d",&a,&b,&c);

    printf("%d %d",gcd3(a,b,c),lcm3(a,b,c));

    return 0;
}