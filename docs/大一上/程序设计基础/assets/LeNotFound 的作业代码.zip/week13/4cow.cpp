#include<bits/extc++.h>

using namespace std;
using namespace __gnu_pbds;
using namespace __gnu_cxx;

inline long long read()
{
    long long x=0,f=1;
    char ch=getchar();
    while(!isdigit(ch))
    {
        if(ch=='-')
        {
            f=-1;
        }
        ch=getchar();
    }
    while(isdigit(ch))
    {
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}

typedef long long ll;
typedef unsigned long long ull;
typedef long double ld;

// 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15
// 1 1 1 2 3 4 5 7 10 14 

ll dfs(ll n)
{
    if(n==0)
    {
        return 1;
    }
    if(n==1||n==2||n==3)
    {
        return 1;
    }
    return dfs(n-1)+dfs(n-4);
}

int main()
{
    puts("Please input require years:");
    ll n=read();

    ll ans=dfs(n);

    cout<<"After "<<n<<" years,there are "<<ans<<" cows.";
    
    // Debug
    // int Debuger=0;
    // cin>>Debuger;
    return 0;
}



