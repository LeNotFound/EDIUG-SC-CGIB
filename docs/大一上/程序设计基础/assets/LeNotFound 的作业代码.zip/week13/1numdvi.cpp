#include<bits/extc++.h>

using namespace std;
using namespace __gnu_pbds;
using namespace __gnu_cxx;

inline long long read()
{
    long long x=0,f=1;
    char ch=getchar();
    while(!isdigit(ch))
    {
        if(ch=='-')
        {
            f=-1;
        }
        ch=getchar();
    }
    while(isdigit(ch))
    {
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}

typedef long long ll;
typedef unsigned long long ull;
typedef long double ld;

vector<bool> isprima(100005,true);

vector<ll> prime;

void init()
{
    isprima[0]=isprima[1]=false;
    for(int i=2;i<=100000;i++)
    {
        if(isprima[i])
        {
            for(int j=i+i;j<=100000;j+=i)
            {
                isprima[j]=false;
            }
        }
    }

    for(ll i=2;i<=100000;i++)
    {
        if(isprima[i])
        {
            prime.push_back(i);
        }
    }
}

int main()
{
    init();

    ll n=read();

    set<ll> ans;

    for(ll i=1;i<=n;i++)
    {
        ll x=read();

        ll j=0;

        while(x!=1)
        {
            if(x%prime[j]==0)
            {
                ans.insert(prime[j]);
                while(x%prime[j]==0)
                {
                    x/=prime[j];
                }
            }
            j++;
        }
    }

    set<ll>::iterator it=ans.begin();

    for(;it!=ans.end();it++)
    {
        cout<<*it<<" ";
    }

    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    // 怎么还不支持 C++14
    
    // Debug
    // int Debuger=0;
    // cin>>Debuger;
    return 0;
}